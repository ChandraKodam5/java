package com.cv.java.lang.clone.shallow;

/**
 * @author Chandra
 * 
 */
// Contains a reference of Employee and
// implements Clonable interface with shallow copy.
public class Employee implements Cloneable {
	
	private String name;
	private int id;
	private Project project = new Project();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}