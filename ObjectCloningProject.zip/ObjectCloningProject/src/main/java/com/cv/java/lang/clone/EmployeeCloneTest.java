package com.cv.java.lang.clone;

/**
 * @author Chandra
 *
 */
// Created an EmployeeCloneTest class for testing the clone() method
public class EmployeeCloneTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creating an Employee object by using new operator with name="CV" and id=201
		Employee employee1 = new Employee("CV", 201);
		System.out.println("Before cloning applied :: ");
		// Printing the employee object
		System.out.println(employee1 + "\n");

		try {
			// Creating an Employee object by using clone method
			Employee employee2 = (Employee) employee1.clone();
			System.out.println("Cloned object :: ");
			
			System.out.println(employee2 + "\n");
			
			System.out.println(employee1 != employee2);

			System.out.println(employee1.getClass() == employee2.getClass());

			System.out.println(employee1.equals(employee2));

		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

	}

}
