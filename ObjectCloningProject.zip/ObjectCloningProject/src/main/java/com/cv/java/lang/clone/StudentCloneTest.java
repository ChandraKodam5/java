package com.cv.java.lang.clone;

/**
 * @author Chandra
 *
 */
//Created a StudentCloneTest class for testing the clone() method
public class StudentCloneTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creating a Student object by using new operator with name="CV" and id=201
		Student student1 = new Student("CV", 201);
		System.out.println("Before cloning applied :: ");
		System.out.println(student1 + "\n");

		try {
			// Creating a Student object by using clone method
			Student student2 = (Student) student1.clone();
			System.out.println("Cloned object :: ");

			System.out.println(student2);

			// Modifying the cloned object
			// And, it is NOT updating or modifying the actual object
			student2.setName("Narasimha");
			student2.setId(202);
			System.out.println("\nAfter modifying cloned object :: ");
			System.out.println("Actual object - " + student1);
			System.out.println("Cloned object - " + student2);

			// Modifying the actual object
			// And, it is NOT updating or modifying the cloned object
			student1.setName("Chandra");
			student1.setId(203);
			System.out.println("\nAfter modifying actual object :: ");
			System.out.println("Actual object - " + student1);
			System.out.println("Cloned object - " + student2);

		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

	}

}
