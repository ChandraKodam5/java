package com.cv.java.lang.clone.shallow;
/**
 * @author Chandra
 * 
 */

//Created a EmployeeTest class for testing the shallow cloning
public class EmployeeTest {
	public static void main(String args[]) throws CloneNotSupportedException {
		// Instantiated employee object by setting name and id
		// Setting the Project fields to employee object
		Employee originalEmployee = new Employee();
		originalEmployee.setName("CV");
		originalEmployee.setId(101);
		originalEmployee.getProject().setName("Loans");
		originalEmployee.getProject().setId(901);
		System.out.println("Output before cloning :: ");
		System.out.println(originalEmployee.getId() + " " + originalEmployee.getName() + " "
				+ originalEmployee.getProject().getName() + " " + originalEmployee.getProject().getId());
		// Getting the clone object from employee
		Employee clonedEmployee = (Employee) originalEmployee.clone();
		System.out.println("Output after modifying original object :: ");
		// Modifying the employee id value of original object
		originalEmployee.setId(102);

		// Modifying the Project id of original employee object
		originalEmployee.getProject().setId(902);

		// Change in actual object fields will be effected in cloned object or vice versa
		// This is happens with shallow cloning
		System.out.println(originalEmployee.getId() + " " + originalEmployee.getName() + " "
				+ originalEmployee.getProject().getName() + " " + originalEmployee.getProject().getId());
		System.out.println(clonedEmployee.getId() + " " + clonedEmployee.getName() + " "
				+ clonedEmployee.getProject().getName() + " " + clonedEmployee.getProject().getId());

		System.out.println("Output after modifying cloned object :: ");
		// Modifying the employee id value of cloned object
		clonedEmployee.setId(103);

		// Modifying the Project id of cloned employee object
		clonedEmployee.getProject().setId(903);

		// Change in cloned object fields will be effected in original object or vice versa
		// This is happens with shallow cloning
		System.out.println(originalEmployee.getId() + " " + originalEmployee.getName() + " "
				+ originalEmployee.getProject().getName() + " " + originalEmployee.getProject().getId());
		System.out.println(clonedEmployee.getId() + " " + clonedEmployee.getName() + " "
				+ clonedEmployee.getProject().getName() + " " + clonedEmployee.getProject().getId());

	}
}