package com.cv.java.lang.clone.deep;

/**
 * @author Chandra
 * 
 */
// Contains a reference of Employee and
// implements Clonable interface with shallow copy.
public class Employee implements Cloneable {
	private String name;
	private int id;
	private Project project = new Project();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Object clone() throws CloneNotSupportedException {
		// Assign the shallow copy to new reference variable
		Employee emp = (Employee) super.clone();

		// Create a new object for the field project
		// and assign it to shallow copy obtained,
		// to make it a deep copy
		emp.project = new Project();
		emp.project.setName(project.getName());
		emp.project.setId(project.getId());
		
		return emp;
	}
}