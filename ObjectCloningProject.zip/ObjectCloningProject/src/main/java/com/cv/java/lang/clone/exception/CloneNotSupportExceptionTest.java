package com.cv.java.lang.clone.exception;

/**
 * @author Chandra
 *
 */
//Created a CloneNotSupportExceptionTest class for testing the Clone Not Support Exception
public class CloneNotSupportExceptionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Student student1 = new Student("Chandra", 201);
		System.out.println(student1);

		try {
			// Creating a Student object by using clone method
			Student Student = (Student) student1.clone();
			System.out.println(Student);

		} catch (CloneNotSupportedException e) {
			System.err.println("Cloning not supported here.");
			System.err.println("Because, Student class is not implemented Clonable interface.");
		}

	}

}
