package com.cv.java.lang.objectcopy;

/**
 * @author Chandra
 * 
 */
// Java program to demonstrate the assignment operator
// only creates a new reference to same object
public class PersonTest {
	public static void main(String[] args) {

		Person person = new Person("CV", 30);

		System.out.println(person.getName() + " - " + person.getAge());

		// Creating a new reference variable person2 pointing to same address as person
		Person person2 = person;

		// Any change made in person2 will be reflected in person
		person2.setAge(31);

		System.out.println(person.getName() + " - " + person.getAge());
		System.out.println(person2.getName() + " - " + person2.getAge());
	}
}