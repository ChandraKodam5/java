package com.cv.java.lang.clone.shallow;

/**
 * @author Chandra
 * 
 */
//Created a Project class
//Overridden toString() method
//Created fields name and id
public class Project {

	private String name;
	private int id;

	public Project() {

	}

	public Project(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Project [name=" + name + ", id=" + id + "]";
	}

}
