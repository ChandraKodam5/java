/**
 * 
 */
package com.cv.java.equalshashcode;

import java.util.HashMap;
import java.util.Map;

import com.cv.java.keys.Person;

/**
 * @author Chandra
 *
 */
public class ProblemOfOverridingOnlyEquals {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Using a Custom object (Person) as a Key to HashMap
		//Overridden ONLY equals(Object) method in custom class
		//We are getting invalid result, because, 
		//we have NOT overridden hashCode method in custom (Person) class
		Map<Person, Integer> map = new HashMap<>();
		Person person1 = new Person("CV", 34);
		Person person2 = new Person("CV", 34);
		Person person3 = new Person("SV", 30);
		
		//Actually, person2 should replace the person1 because both keys (contents) are equal.
		//IT IS NOT HAPPENING
		//Because, we have NOT overridden hashCode method in custom (Person) class
		map.put(person1, 1);
		map.put(person2, 2);
		map.put(person3, 3);
		
		System.out.println(person1.hashCode());//1101288798
		System.out.println(person2.hashCode());//942731712
		System.out.println(person3.hashCode());//971848845
		System.out.println(person1.equals(person2));//true
		
		System.out.println(map);
		
		//{Person [name=CV, age=34]=2, Person [name=SV, age=30]=3, Person [name=CV, age=34]=1}

	}

}

