/**
 * 
 */
package com.cv.java.equalshashcode;

import com.cv.java.keys.Employee;

/**
 * @author Chandra
 *
 */
public class PriniciplesOfEquals {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Employee e1 = new Employee(1001, "CV", 4000.00);
		Employee e2 = new Employee(1001, "CV", 4000.00);
		Employee e3 = new Employee(1001, "CV", 4000.00);
		
		System.out.println("Reflexive - Principle !");
		System.out.println(e1.equals(e1));//true - Reflexive
		
		System.out.println("Symmetric - Principle !");
		System.out.println(e1.equals(e2));//true
		System.out.println(e2.equals(e1));//true - Symmetric
		
		System.out.println("Transitive - Principle !");
		System.out.println(e1.equals(e2));//true
		System.out.println(e2.equals(e3));//true 
		System.out.println(e1.equals(e3));//true - Transitive
		
		System.out.println("Consistent - Principle !");
		for (int i = 0; i < 5; i++) {
			System.out.println(e1.equals(e2));//true - Consistent	
		}
		System.out.println("Note - passing null !");
		System.out.println(e1.equals(null));//false
	}
}
