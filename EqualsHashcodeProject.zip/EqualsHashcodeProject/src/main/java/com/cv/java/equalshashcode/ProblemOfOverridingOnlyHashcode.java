/**
 * 
 */
package com.cv.java.equalshashcode;

import java.util.HashMap;
import java.util.Map;

import com.cv.java.keys.User;

/**
 * @author Chandra
 *
 */
public class ProblemOfOverridingOnlyHashcode {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//Using a Custom object (User) as a Key to HashMap
		//Overridden ONLY hashcode method in custom class
		//We are getting invalid result, because, 
		//we have NOT overridden equals(Object) method in custom (User) class
		Map<User, Integer> map = new HashMap<>();
		User user1 = new User("CV", 101);
		User user2 = new User("CV", 101);
		User user3 = new User("SV", 102);
		//Actually, user2 should replace the user1 because both keys (contents) are equal.
		//IT IS NOT HAPPENING
		//Because, we have NOT overridden equals(Object) method in custom (User) class
		map.put(user1, 1);
		map.put(user2, 2);
		map.put(user3, 3);

		System.out.println(user1.hashCode());//6255
		System.out.println(user2.hashCode());//6255
		System.out.println(user3.hashCode());//6782

		System.out.println(user1.equals(user2));//false

		System.out.println(map);
		//{User [name=SV, id=102]=3, User [name=CV, id=101]=1, User [name=CV, id=101]=2}

	}

}
