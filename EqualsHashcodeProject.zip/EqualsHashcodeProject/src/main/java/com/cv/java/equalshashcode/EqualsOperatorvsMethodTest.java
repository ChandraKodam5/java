/**
*
*/
package com.cv.java.equalshashcode;

/**
 * @author Chandra
 *
 */

public class EqualsOperatorvsMethodTest {
	/**
	 * @param args
	 */
	public static void main(String[] args) {		
		
		System.out.println("---- ### String literal ### ----");
		
		//String immutability helps to get true for == operator
		String s1 = "CV";
		String s2 = "CV";
		System.out.println(s1 == s2);//true
		System.out.println(s1.equals(s2));//true
		
		System.out.println("---- ### String Object ### ----");
		
		//Tough, we are creating the String objects with same content
		//JVM creates Strings in two different addresses, 
		//means, allowcates two different heap memory locations
		//Due to that, we are getting false for == operator
		String s3 = new String("CV");
		String s4 = new String("CV");
		System.out.println(s3 == s4);//false
		System.out.println(s3.equals(s4));//true
		
		//Passing object reference as a parameter to the String equals(Object) method. 
		//But, it is the actual object of String. Which is valid. 
		//Due to that, we are getting as true.
		Object obj = new String("CV");
	    System.out.println(s3.equals(obj));//true
        
        System.out.println("---- ### StringBuffer Object ### ----");
        
        StringBuffer sb1 = new StringBuffer("CV");
        StringBuffer sb2 = new StringBuffer("CV");
        System.out.println(sb1 == sb2);//false
        System.out.println(sb1.equals(sb2));//false  
        
        //Passing String Buffer reference as a parameter to the String equals(Object) method. 
        //But, it is NOT instance of String. Because of that, we are getting as false.
        System.out.println(s3.equals(sb2));//false
        
        System.out.println("---- ### Thread Object ### ----");
		
		Thread t1 = new Thread();
        Thread t2 = new Thread();
        Thread t3 = t1;   
        System.out.println(t1 == t2);//false
        System.out.println(t1 == t3);//true
        System.out.println(t1.equals(t2));//false
        System.out.println(t1.equals(t3)); //true
        
	}
}