package com.cv.java.keys;

/**
 * @author Chandra
 *
 */

//An immutable class named as User
//Using object of this as a Key to HashMap
//Overridden ONLY hashCode() method
//But it has a problem, we have not overridden the equals(Object) method 
//to show importance of equals(Object) method.
public final class User {

	private final String name;
	private final Integer id;

	public User(String name, Integer id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public Integer getId() {
		return id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", id=" + id + "]";
	}

}
