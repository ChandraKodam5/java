package com.cv.java.keys;

/**
 * @author Chandra
 *
 */

//An immutable class named as Person

//Using object of this as a Key to HashMap
//Overridden ONLY equals(Object) method
//But, it has a problem, we have not overridden the hashCode method 
//to show importance of hashCode method. 

public final class Person {

	private final String name;
	private final Integer age;

	public Person(String name, Integer age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public Integer getAge() {
		return age;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (age == null) {
			if (other.age != null)
				return false;
		} else if (!age.equals(other.age))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
}
