/**
 * 
 */
package com.cv.java.equalshashcode;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cv.java.keys.Employee;

/**
 * @author Chandra
 *
 */
public class CustomKeyInHashMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Using a Custom object (Employee) as a Key to HashMap
		//Overridden equals(Object), hashcode and compareTo(Object) methods in custom(Employee) class
		//It is mandatory, when we are using it as key to HashMap, HashSet or Hashtable
		Employee employee1 = new Employee(1001, "CV", 4000.00);
		Employee employee2 = new Employee(102, "SV", 5000.00);
		Employee employee3 = new Employee(103, "Narasimha", 5500.00);
		Employee employee4 = new Employee(1001, "CV", 4000.00);

		Map<Employee, Integer> employees = new HashMap<>();

		//employee4 should replace the employee1 because both keys(contents) are equal.
		//And, 1 value should replace with 4 value
		employees.put(employee1, 1);
		employees.put(employee2, 2);
		employees.put(employee3, 3);
		employees.put(employee4, 4);

		for (Entry<Employee, Integer> entry : employees.entrySet()) {
			System.out.println(entry.getKey() + " - " + entry.getValue());
		}
		
		//Output
		//Employee [id=102, name=SV, salary=5000.0] - 2
		//Employee [id=103, name=Narasimha, salary=5500.0] - 3
		//Employee [id=1001, name=CV, salary=4000.0] - 4

	}

}
