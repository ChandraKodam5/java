/**
 * 
 */
package com.cv.java.equalshashcode;

/**
 * @author Chandra
 *
 */
public class ContractOfEqualsHashcode {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("---- ### StringBuffer Object ### ----");
		
		StringBuffer sb1 = new StringBuffer("CV");
		StringBuffer sb2 = sb1;
		System.out.println(sb1.equals(sb2));//true
		System.out.println(sb1.hashCode() == sb2.hashCode());//true
		System.out.println(sb1.hashCode() + " - " + sb2.hashCode());//305623748 - 305623748
		
		System.out.println("---- ### StringBuffer Object ### ----");
		
		StringBuffer sb3 = new StringBuffer("CV");
		StringBuffer sb4 = new StringBuffer("CV");
		//String Buffer does NOT override equals(Object) & hashCode method
		System.out.println(sb3.equals(sb4));//false
		System.out.println(sb3.hashCode() == sb4.hashCode());//false
		System.out.println(sb3.hashCode() + " - " + sb4.hashCode());//758529971 - 2104457164
		
		System.out.println("---- ### Objects are equal produce same hashcode ### ----");
		String s1 = new String("cv");
		String s2 = new String("cv");
		System.out.println(s1.equals(s2));//true
		System.out.println(s1.hashCode() == s2.hashCode());//true
		System.out.println(s1.hashCode() + " - " + s2.hashCode());//3187 - 3187
		
		System.out.println("---- ### Objects are NOT equal may produce same hashcode ### ----");
		String s3 = new String("Aa");
		String s4 = new String("BB");
		//One of the interview question,
		//It is possible to have two DIFFERENT Strings can have SAME hashcode.
		System.out.println(s3.equals(s4));//false
		System.out.println(s3.hashCode() == s4.hashCode());//true
		System.out.println(s3.hashCode() + " - " + s4.hashCode());//2112 - 2112
		

	}

}
