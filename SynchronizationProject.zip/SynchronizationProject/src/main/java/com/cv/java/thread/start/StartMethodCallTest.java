package com.cv.java.thread.start;

/**
 * @author Chandra
 *
 */
//Created a StartMethodCallTest class
//Testing the start() method of ThreadImpl class and RunnableImpl interface
public class StartMethodCallTest {
	public static void main(String args[]) {
		ThreadImpl t1 = new ThreadImpl();
		t1.setName("ThreadImpl thread");
		Thread t2 = new Thread(new RunnableImpl());
		t2.setName("RunnableImpl thread");
		//It calls the start() method of ThreadImpl class, 
		//Because, we have overridden the start() method of Thread class.
		//IT IS NOT RECOMMENDED TO OVERRIDE start() method in thread class
		t1.start();
		//It calls the start() method of Thread class, 
		//Because, we have NOT overridden the start() method of Thread class.
		//We have just written a normal start() method in the RunnableImpl class
		t2.start();
	}
}