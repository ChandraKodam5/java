/**
 * 
 */
package com.cv.java.thread;

/**
 * @author Chandra
 *
 */
//Created an PrimeTest class for testing the thread concept
public class PrimeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Creating a Thread object
		PrimeThread thread = new PrimeThread(143);
		//Starting a Thread
		thread.start();
	}

}
