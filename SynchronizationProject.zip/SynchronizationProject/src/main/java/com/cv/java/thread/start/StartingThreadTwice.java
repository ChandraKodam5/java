package com.cv.java.thread.start;

/**
 * @author Chandra
 *
 */
//Created a StartingThreadTwice class
//Testing the start() method calling of FirstThread class TWICE
public class StartingThreadTwice {
	public static void main(String args[]) {
		FirstThread t1 = new FirstThread();
		t1.setName("FirstThread Thread");
		t1.start();
		//We should NOT call start() method TWICE
		//In case, we call start() twice then we will get java.lang.IllegalThreadStateException
		t1.start();
	}
}