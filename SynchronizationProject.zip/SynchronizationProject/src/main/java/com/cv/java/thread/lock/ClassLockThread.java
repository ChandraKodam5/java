package com.cv.java.thread.lock;

/**
 * @author Chandra
 *
 */
// Java program to illustrate class level lock
public class ClassLockThread implements Runnable {
	public void run() {
		lock();
	}

	public void lock() {
		System.out.println(Thread.currentThread().getName());
		//class level lock has applied here
		synchronized (ClassLockThread.class) {
			System.out.println("in block " + Thread.currentThread().getName());
			System.out.println("in block " + Thread.currentThread().getName() + " end");
		}
	}

	public static void main(String[] args) {
		ClassLockThread classLock1 = new ClassLockThread();
		Thread t1 = new Thread(classLock1);
		Thread t2 = new Thread(classLock1);
		ClassLockThread classLock2 = new ClassLockThread();
		Thread t3 = new Thread(classLock2);
		t1.setName("Thread 1");
		t2.setName("Thread 2");
		t3.setName("Thread 3");
		t1.start();
		t2.start();
		t3.start();
	}
}