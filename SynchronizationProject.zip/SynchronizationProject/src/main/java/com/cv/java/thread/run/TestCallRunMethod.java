package com.cv.java.thread.run;

/**
 * @author Chandra
 *
 */
//Created a TestCallRunMethod class
//Overridden run() method
//But, calling the run() directly from thread object (which is INCORRECT )
public class TestCallRunMethod extends Thread {
	
	public void run() {
		System.out.println(Thread.currentThread().getName());
		for (int i = 1; i < 5; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			System.out.println(i);
		}
	}

	public static void main(String args[]) {
		TestCallRunMethod t1 = new TestCallRunMethod();
		TestCallRunMethod t2 = new TestCallRunMethod();
		t1.setName("First Thread");
		t2.setName("Second Thread");
		//Though, run() method has overridden in this class, but, 
		//we are calling directly from thread object.
		//Since, it is NOT being called by thread schedular then it is producing different result.
		t1.run();
		t2.run();
	}
}