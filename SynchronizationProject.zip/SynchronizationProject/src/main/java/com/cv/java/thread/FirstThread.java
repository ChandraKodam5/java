package com.cv.java.thread;

/**
 * @author Chandra
 *
 */
//Created a FirstThread class which extends Thread class
//Overridden run() method
public class FirstThread extends Thread {
	public void run() {
		System.out.println("FirstThread is running...");
	}

	public static void main(String args[]) {
		//Creating a Thread object
		FirstThread t1 = new FirstThread();
		//Starting a Thread
		t1.start();
	}
}