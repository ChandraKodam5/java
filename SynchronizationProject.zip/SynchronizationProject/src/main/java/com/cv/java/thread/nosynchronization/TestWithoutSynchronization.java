package com.cv.java.thread.nosynchronization;

/**
 * @author Chandra
 *
 */
// Created a TestWithoutSynchronization class
// Using this class to test the threads concept without synchronization.
// Using multiple threads to communicate each other
public class TestWithoutSynchronization {
	public static void main(String args[]) {
		Table table = new Table();// only one object
		FirstThread thread1 = new FirstThread(table);
		thread1.setName("First Thread");
		SecondThread thread2 = new SecondThread(table);
		thread2.setName("Second Thread");
		thread1.start();
		thread2.start();
	}
}