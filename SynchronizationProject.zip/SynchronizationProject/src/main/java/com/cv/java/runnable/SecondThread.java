package com.cv.java.runnable;

/**
 * @author Chandra
 *
 */
//Created a SecondThread class which implements Runnable interface
//Overridden run() method
public class SecondThread implements Runnable {
	public void run() {
		System.out.println("SecondThread is running...");
	}

	public static void main(String args[]) {
		//Creating a Thread by passing Runnable object as a parameter to the Thread constructor
		Thread t2 = new Thread(new SecondThread());
		//Starting a Thread
		t2.start();
	}
}