package com.cv.java.thread.run;

/**
 * @author Chandra
 *
 */
//Created a TestCallRunMethodThroughStartMethod class
//Overridden run() method
//Calling the run() method from start() method of thread object ( which is CORRECT ) 
public class TestCallRunMethodThroughStartMethod extends Thread {

	public void run() {
		System.out.println(Thread.currentThread().getName());
		for (int i = 1; i < 5; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			System.out.println(i);
		}
	}

	public static void main(String args[]) {
		TestCallRunMethodThroughStartMethod t1 = new TestCallRunMethodThroughStartMethod();
		TestCallRunMethodThroughStartMethod t2 = new TestCallRunMethodThroughStartMethod();
		t1.setName("First Thread");
		t2.setName("Second Thread");
		// run() method has overridden in this class, and,
		// we are indirectly calling from thread schedular.
		// Means, start() method calls run() method
		t1.start();
		t2.start();
	}
}