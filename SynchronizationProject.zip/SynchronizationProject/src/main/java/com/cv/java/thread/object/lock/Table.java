/**
 * 
 */
package com.cv.java.thread.object.lock;

/**
 * @author Chandra
 *
 */
//Created a Table class used as communicated object to the threads
public class Table {
	int input = 1;

	public Table() {

	}

	public Table(int input) {
		this.input = input;
	}

	public void printTable(final int n) {
		int n2 = input * n;
		//Applying the object level locking with the help of synchronized block
		synchronized (this) {
			System.out.println(Thread.currentThread().getName());
			for (int i = 1; i <= 10; ++i) {
				System.out.println(n2 * i);
				try {
					Thread.sleep(100);
				} catch (Exception e) {
					System.err.println(e);
				}
			}
		}

	}
}