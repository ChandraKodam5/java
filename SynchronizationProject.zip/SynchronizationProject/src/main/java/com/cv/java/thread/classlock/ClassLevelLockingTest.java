package com.cv.java.thread.classlock;

/**
 * @author Chandra
 *
 */
//Created a ClassLevelLockingTest class
//Using this class to test the threads concept with synchronization & applying class level locking.
//Using multiple threads to communicate each other
public class ClassLevelLockingTest {
	public static void main(String args[]) {
		// Creating the Table object that is being shared by multiple threads
		Table table = new Table(2);
		FirstThread thread1 = new FirstThread(table);
		thread1.setName("First Thread");
		SecondThread thread2 = new SecondThread(table);
		thread2.setName("Second Thread");
		// Creating the Table object that is being shared by multiple threads
		Table table2 = new Table(5);
		FirstThread thread3 = new FirstThread(table2);
		thread3.setName("Third Thread");
		thread1.start();
		thread2.start();
		thread3.start();
	}
}