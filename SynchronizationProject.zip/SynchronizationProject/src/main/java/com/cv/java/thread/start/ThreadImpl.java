package com.cv.java.thread.start;
/**
 * @author Chandra
 *
 */
//Created a ThreadImpl class which extends Thread class
//Overridden run() and start() methods
public class ThreadImpl extends Thread {
	
	//It is recommended to override ONLY run() method in every class which extended Thread class
	@Override
	public void run() {
		System.out.println("Name of the thread is :: "+Thread.currentThread().getName());
		System.out.println("ThreadImpl: run()");
	}
	//It acts like an overridden method of Thread class. 
	//It is NOT recommended to override start() method in any class which extended Thread class
	@Override
	public void start() {
		System.out.println("ThreadImpl: start()");
	}
}
