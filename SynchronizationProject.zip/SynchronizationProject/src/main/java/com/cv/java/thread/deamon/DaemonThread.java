package com.cv.java.thread.deamon;

/**
 * @author Chandra
 *
 */
// Java program to demonstrate the usage of 
// setDaemon() and isDaemon() method.
public class DaemonThread extends Thread {
	public DaemonThread(String name) {
		super(name);
	}

	public void run() {
		// Checking whether the thread is Daemon or not
		if (Thread.currentThread().isDaemon()) {
			System.out.println(getName() + " is Daemon thread");
		}

		else {
			System.out.println(getName() + " is User thread");
		}
	}

	public static void main(String[] args) {

		DaemonThread t1 = new DaemonThread("Thread 1");
		DaemonThread t2 = new DaemonThread("Thread 2");
		DaemonThread t3 = new DaemonThread("Thread 3");

		// Setting user thread t1 to Daemon
		//We should set to Daemon before starting the thread.
		t1.setDaemon(true);

		// starting first 2 threads
		t1.start();
		t2.start();
		
		//We should NOT set to Daemon after starting the thread.
		//In case, we set to daemon after starting the thread then we will get 
		//java.lang.IllegalThreadStateException.
		//t2.setDaemon(true);

		// Setting user thread t3 to Daemon
		t3.setDaemon(true);
		t3.start();
		
		System.out.println("Main thread name :: "+Thread.currentThread().getName());
		System.out.println("Is main thread daemon :: "+ Thread.currentThread().isDaemon());
	}
}