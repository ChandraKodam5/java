package com.cv.java.thread.lock;

/**
 * @author Chandra
 *
 */
// Java program to illustrate Object lock concept
public class ObjectLockThread implements Runnable {
	public void run() {
		lock();
	}

	public void lock() {
		System.out.println(Thread.currentThread().getName());
		//Object level lock has applied here
		synchronized (this) {
			System.out.println("in block " + Thread.currentThread().getName());
			System.out.println("in block " + Thread.currentThread().getName() + " end");
		}
	}

	public static void main(String[] args) {
		ObjectLockThread objectLock1 = new ObjectLockThread();
		Thread t1 = new Thread(objectLock1);
		Thread t2 = new Thread(objectLock1);
		ObjectLockThread objectLock2 = new ObjectLockThread();
		Thread t3 = new Thread(objectLock2);
		t1.setName("Thread 1");
		t2.setName("Thread 2");
		t3.setName("Thread 3");
		t1.start();
		t2.start();
		t3.start();
	}
}