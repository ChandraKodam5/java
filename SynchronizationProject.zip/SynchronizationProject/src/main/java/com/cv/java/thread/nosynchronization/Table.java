/**
 * 
 */
package com.cv.java.thread.nosynchronization;

/**
 * @author Chandra
 *
 */
//Created a Table class used as communicated object to the threads
public class Table {
	// method not synchronized
	public void printTable(final int n) {
		System.out.println(Thread.currentThread().getName());
		for (int i = 1; i <= 10; i++) {
			System.out.println(n * i);
			try {
				Thread.sleep(100);
			} catch (Exception e) {
				System.err.println(e);
			}
		}

	}
}