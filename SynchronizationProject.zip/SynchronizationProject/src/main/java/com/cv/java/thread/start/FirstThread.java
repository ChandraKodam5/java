/**
 * 
 */
package com.cv.java.thread.start;

/**
 * @author Chandra
 *
 */
//Created a FirstThread class which extends Thread class
//Overridden run() method
public class FirstThread extends Thread {


	@Override
	public void run() {
		System.out.println("Name of the thread is :: "+Thread.currentThread().getName());
		System.out.println("FirstThread: run()");
	}
}