/**
 * 
 */
package com.cv.java.thread.synchronization;

/**
 * @author Chandra
 *
 */
//Created a FirstThread class which extends Thread class
//Overridden run() method
public class FirstThread extends Thread {
	private Table table;

	public FirstThread(Table table) {
		this.table = table;
	}

	@Override
	public void run() {
		table.printTable(5);
	}
}