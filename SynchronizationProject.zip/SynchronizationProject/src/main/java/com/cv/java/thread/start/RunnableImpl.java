package com.cv.java.thread.start;

/**
 * @author Chandra
 *
 */
//Created a RunnableImpl class which implements Runnable interface
//Overridden ONLY run() method
public class RunnableImpl implements Runnable {
	
	@Override
	public void run() {
		System.out.println("Name of the thread is :: "+Thread.currentThread().getName());
		System.out.println("RunnableImpl: run()");
	}
	
	//It acts like a normal method of RunnableImpl. 
	//But, does NOT act like overridden method of Runnable interface.
	//Since, Runnable interface does NOT contain start()
	//@Override
	public void start() {
		System.out.println("RunnableImpl: start()");
	}
}