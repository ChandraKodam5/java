package com.cv.java.thread.start;

/**
 * @author Chandra
 *
 */
//Created a StartCallTest class
//Testing the start() method of ThreadImpl class
public class StartCallTest {
	public static void main(String args[]) {
		ThreadImpl t1 = new ThreadImpl();
		t1.setName("ThreadImpl thread");
		//It is valid to call .start() method of ThreadImpl class
		//But, we have overridden start() method in the ThreadImpl class ( which is INVALID)
		t1.start();
		System.out.println("Main method...");
	}
}