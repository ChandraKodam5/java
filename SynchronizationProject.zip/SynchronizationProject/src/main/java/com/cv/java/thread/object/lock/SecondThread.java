/**
 * 
 */
package com.cv.java.thread.object.lock;

/**
 * @author Chandra
 *
 */
//Created a SecondThread class which extends Thread class
//Overridden run() method
public class SecondThread extends Thread {
	
	private Table table;

	public SecondThread(Table table) {
		this.table = table;
	}

	@Override
	public void run() {
		table.printTable(10);
	}
}