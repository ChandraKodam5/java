/**
 * 
 */
package com.cv.java.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cv.java.keys.Operator;

/**
 * @author Chandra
 *
 */
public class NonImmutableCustomKeyInHashMap {
	/**
	 * @param args
	 */
	public static void main(String[] args) {

// 		Using a custom object (Operator) as a Key to HashMap
// 		Overridden equals(Object), hashcode and compareTo(Object) methods in Operator class
// 		It is mandatory to override equals(Object), hashCode and compareTo(Object) methods,
// 		when we are using a custom class as a KEY to HashMap, HashSet or Hashtable

		Operator operator1 = new Operator(101, "CV");
		Operator operator2 = new Operator(102, "SV");
		Operator operator3 = new Operator(103, "Narasimha");
		Operator operator4 = new Operator(101, "CV");
		
//		Created a empty HashMap with Operator as a Key and Integer as a value.
		Map<Operator, Integer> operators = new HashMap<>();

// 		operator4 should replace the operator1 because both keys(contents) are equal.
// 		And, Hy, In value should replace with WG, IN value
		operators.put(operator1, 1);
		operators.put(operator2, 2);
		operators.put(operator3, 3);
		operators.put(operator4, 4);

		for (Entry<Operator, Integer> entry : operators.entrySet()) {
			System.out.println(entry.getKey() + " :: " + entry.getValue());
		}
// 		Program is fine till this point.
		System.out.println();
		System.out.println("Fetching operator3 before modification ::  " + operators.get(operator3));

		operator3.setName("Chandra");
		Operator operator5 = new Operator(103, "Chandra");

		System.out.println("Fetching operator3 after modification ::  " + operators.get(operator3));
		System.out.println("Fetching operator3 after modification ::  " + operators.get(operator5));
		System.out.println();
		for (Entry<Operator, Integer> entry : operators.entrySet()) {
			System.out.println(entry.getKey() + " :: " + entry.getValue());
		}

	}
// 		Output
// 		Operator [name=Narasimha, id=103] :: 3
// 		Operator [name=SV, id=102] :: 2
// 		Operator [name=CV, id=101] :: 4

// 		Fetching operator3 before modification ::  3
// 		Fetching operator3 after modification ::  null
// 		Fetching operator3 after modification ::  null

// 		Operator [name=Chandra, id=103] :: 3
// 		Operator [name=SV, id=102] :: 2
// 		Operator [name=CV, id=101] :: 4

}
