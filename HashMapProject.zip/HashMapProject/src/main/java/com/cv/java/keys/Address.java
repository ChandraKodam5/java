/**
 * 
 */
package com.cv.java.keys;

/**
 * @author Chandra
 *
 */

//An immutable class named as Address
public final class Address implements java.io.Serializable, Comparable<Address> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String city;
	private final String country;

	public Address(String city, String country) {
		super();
		this.city = city;
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public String getCountry() {
		return country;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());

		System.out.println("In - " + this.getClass().getName() + " : : hashCode - " + result);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("In - " + this.getClass().getName() + " : : equals(-)");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		return true;
	}

	@Override
	public int compareTo(Address address) {
		System.out.println("In - " + this.getClass().getName() + " : : compareTo(-)");
		int tempId = 0;
		if ((tempId = this.getCity().compareTo(address.getCity())) != 0) {
			return tempId;
		} else if ((tempId = this.getCountry().compareTo(address.getCountry())) != 0) {
			return tempId;
		}
		return tempId;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", country=" + country + "]";
	}

}
