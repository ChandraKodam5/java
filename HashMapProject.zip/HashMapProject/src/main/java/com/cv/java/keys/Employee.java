/**
 * 
 */
package com.cv.java.keys;

/**
 * @author Chandra
 *
 */

//An immutable class named as Employee
public final class Employee implements java.io.Serializable, Comparable<Employee> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Integer id;
	private final String name;
	private final Double salary;

	public Employee(Integer id, String name, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;

	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Double getSalary() {
		return salary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((salary == null) ? 0 : salary.hashCode());
		System.out.println("In - " + this.getClass().getName() + " : : hashCode - " + result);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("In - " + this.getClass().getName() + " : : equals( - ) ");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (salary == null) {
			if (other.salary != null)
				return false;
		} else if (!salary.equals(other.salary))
			return false;
		return true;
	}

	@Override
	public int compareTo(Employee employee) {
		System.out.println("In - " + this.getClass().getName() + " : : compareTo(-)");
		int tempId = 0;
		if ((tempId = this.getName().compareTo(employee.getName())) != 0) {
			return tempId;
		} else if ((tempId = this.getId().compareTo(employee.getId())) != 0) {
			return tempId;
		} else if ((tempId = this.getSalary().compareTo(employee.getSalary())) != 0) {
			return tempId;
		}
		return tempId;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

}
