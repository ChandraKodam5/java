/**
 * 
 */
package com.cv.java.collections;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Chandra
 *
 */
public class PrimitiveKeyInHashMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		Not possible to create a HashMap with primitives.
//		Map<int, int> map = new HashMap<>();

		String s1 = new String("CV");
		String s2 = new String("SV");
		String s3 = new String("Narasimha");
//		Created a empty HashMap.
//		Map names = new HashMap();
		Map<Integer, String> names = new HashMap<>();
//		We can add primitive to the HashMap but it is NOT recommended
		names.put(1, s1);
		names.put(2, s2);
		names.put(3, s3);

		for (Map.Entry<Integer, String> entry : names.entrySet()) {
			System.out.println(entry.getKey() + " - " + entry.getValue());
		}

		/*
		 * for (Object obj : names.entrySet()) { Map.Entry entry = (Map.Entry)obj;
		 * System.out.println(entry.getKey() + " - " + entry.getValue()); }
		 */

// 		Output

//		1 - CV
//		2 - SV
//		3 - Narasimha

	}

}
