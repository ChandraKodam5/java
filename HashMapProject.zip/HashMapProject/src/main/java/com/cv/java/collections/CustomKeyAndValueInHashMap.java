/**
 * 
 */
package com.cv.java.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cv.java.keys.Address;
import com.cv.java.keys.Employee;

/**
 * @author Chandra
 *
 */
public class CustomKeyAndValueInHashMap {
	/**
	 * @param args
	 */
	public static void main(String[] args) {

// 		Using a custom object (Employee) as a Key to HashMap
// 		Overridden equals(Object), hashcode and compareTo(Object) methods in Employee class
// 		It is mandatory to override equals(Object), hashCode and compareTo(Object) methods,
// 		when we are using a custom class as a KEY to HashMap, HashSet or Hashtable
		Employee employee1 = new Employee(101, "CV", 4000.00);
		Employee employee2 = new Employee(102, "SV", 5000.00);
		Employee employee3 = new Employee(103, "Narasimha", 5500.00);
		Employee employee4 = new Employee(101, "CV", 4000.00);

// 		Using a custom object (Address) as a Value to HashMap
// 		Overridden equals(Object), hashcode and compareTo(Object) methods in Address class
// 		It is NOT mandatory to override equals(Object), hashCode and compareTo(Object) methods,
// 		when we are using a custom class as a VALUE to HashMap or Hashtable
		Address address1 = new Address("Hy", "In");
		Address address2 = new Address("LA", "US");
		Address address3 = new Address("LDN", "UK");
		Address address4 = new Address("WG", "IN");
		
//		Created a empty HashMap with Employee as a Key and Address as a value.
		Map<Employee, Address> employees = new HashMap<>();

// 		employee4 should replace the employee1 because both keys(contents) are equal.
// 		And, Hy, In value should replace with WG, IN value
		employees.put(employee1, address1);
		employees.put(employee2, address2);
		employees.put(employee3, address3);
		employees.put(employee4, address4);
		System.out.println();
		int i = 0;
		for (Entry<Employee, Address> entry : employees.entrySet()) {
			System.out.println("Key : : " + ++i);
			System.out.println(entry.getKey());
			System.out.println("Value : : " + i);
			System.out.println(entry.getValue());
			System.out.println();
		}

// 		Output
		
		/**
		 * Only Employee class hashCode and equals methods are executed. 
		 * Means, Key class related ( hashCode and equals ) methods are executed.
		 * And, Value class related methods are NOT executed.
		 */		
// 		In - com.cv.java.keys.Employee : : hashCode - 1085420913
// 		In - com.cv.java.keys.Employee : : hashCode - 1085717826
// 		In - com.cv.java.keys.Employee : : hashCode - -188712264
// 		In - com.cv.java.keys.Employee : : hashCode - 1085420913
// 		In - com.cv.java.keys.Employee : : equals( - )

//		Key : : 1
//		Employee [id=101, name=CV, salary=4000.0]
//		Value : : 1
//		Address [city=WG, country=IN] // City and country has changed because we have replaced new value

//		Key : : 2
//		Employee [id=102, name=SV, salary=5000.0]
//		Value : : 2
//		Address [city=LA, country=US]

//		Key : : 3
//		Employee [id=103, name=Narasimha, salary=5500.0]
//		Value : : 3
//		Address [city=LDN, country=UK]

	}
	
}
