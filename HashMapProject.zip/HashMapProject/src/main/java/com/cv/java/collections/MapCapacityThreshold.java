/**
 * 
 */
package com.cv.java.collections;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Chandra
 *
 */

public class MapCapacityThreshold {

	static {
		disableWarning();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
// 		Created a empty HashMap with String as a Key and Integer as a value.
		Map<String, Integer> map = new HashMap<>();
		
		System.out.println("Initail size of the map is : : " + map.size());
// 		Initail size of the map is : : 0
// 		Added 12 entries (elements) to HashMap
		map.put("Aa", 1);
		map.put("BB", 2);
		map.put("AaAa", 3);
		map.put("BBBB", 4);
		map.put("AaBB", 5);
		map.put("BBAa", 6);
		map.put("AaAaAa", 7);
		map.put("BBBBBB", 8);
		map.put("AaBBAa", 9);
		map.put("BBAaBB", 10);
		map.put("AaAaBB", 11);
		map.put("BBBBAa", 12);

		System.out.println("Size of the map after adding 12 entries : : " + map.size());
// 		Size of the map after adding 12 entries : : 12

		try {

			Field tableField2 = map.getClass().getDeclaredField("threshold");
			tableField2.setAccessible(true);
			System.out.println("Threshold of the map after adding 12 entries : : " + tableField2.get(map));
// 		Threshold of the map after adding 12 entries : : 12

			Field tableField = map.getClass().getDeclaredField("table");
			tableField.setAccessible(true);
			System.out.println(
					"Capacity of the map after adding 12 entries : : " + ((Object[]) tableField.get(map)).length);
// 		Capacity of the map after adding 12 entries : : 16

			// 		 One more entry (element) is added to HashMap
			map.put("XYZ", 13);

			System.out.println();

			System.out.println("Size of the map is after adding 13 entries : : " + map.size());
// 		Size of the map is after adding 13 entries : : 13

			System.out.println("Threshold of the map  after adding 13 entries : : " + tableField2.get(map));
// 		Threshold gets doubled
// 		Threshold of the map  after adding 13 entries : : 24

			System.out.println(
					"Capacity of the map  after adding 13 entries : : " + ((Object[]) tableField.get(map)).length);
// 		Capacity gets doubled
// 		Capacity of the map  after adding 13 entries : : 32
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}

}

// 		Initail size of the map is : : 0
// 		Size of the map after adding 12 entries : : 12
// 		Threshold of the map after adding 12 entries : : 12
// 		Capacity of the map after adding 12 entries : : 16

// 		Size of the map is after adding 13 entries : : 13
// 		Threshold of the map  after adding 13 entries : : 24
// 		Capacity of the map  after adding 13 entries : : 32
