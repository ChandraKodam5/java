/**
 * 
 */
package com.cv.java.keys;

/**
 * @author Chandra
 *
 */

//An immutable class named as Dummy
//Using object of this as a Key to HashMap
public final class Dummy implements Comparable<Dummy> {

	private final String text;

	public Dummy(String text) {
		super();
		this.text = text;
	}

	public String getText() {
		return text;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		System.out.println("In - " + this.getClass().getName() + " : : hashCode - " + result);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("In - " + this.getClass().getName() + " : : equals(-)");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dummy other = (Dummy) obj;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		return true;
	}
	
	@Override
	public int compareTo(Dummy dummy) {
		System.out.println("In - " + this.getClass().getName() + " : : compareTo(-)");
		int tempId = 0;
		if ((tempId = this.getText().compareTo(dummy.getText())) != 0) {
			return tempId;
		} 
		return tempId;
	}

	
	@Override
	public String toString() {
		return "Dummy [text=" + text + "]";
	}

}
