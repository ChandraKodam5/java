/**
 * 
 */
package com.cv.java.keys;

/**
 * @author Chandra
 *
 */

//NON immutable class named as Operator  
//because, we have written setter methods and class is NOT final
//Using object of this as a Key to HashMap
public class Operator implements Comparable<Operator> {

	private Integer id;
	private String name;

	public Operator(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Operator other = (Operator) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public int compareTo(Operator operator) {
		int tempId = 0;
		if ((tempId = this.getName().compareTo(operator.getName())) != 0) {
			return tempId;
		} else if ((tempId = this.getId().compareTo(operator.getId())) != 0) {
			return tempId;
		}
		return tempId;
	}

	@Override
	public String toString() {
		return "Operator [name=" + name + ", id=" + id + "]";
	}
}
