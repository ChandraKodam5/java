/**
 * 
 */
package com.cv.java.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author Chandra
 *
 */
public class StringKeyInHashMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String s1 = new String("CV");
		String s2 = new String("SV");
		String s3 = new String("Narasimha");
		String s4 = new String("CV");
//		Created a empty HashMap with String as a Key and Integer as a value.
		Map<String, Integer> names = new HashMap<>();

		names.put(s1, 1);
		names.put(s2, 2);
		names.put(s3, 3);
		names.put(s4, 4);

		for (Entry<String, Integer> entry : names.entrySet()) {
			System.out.println(entry.getKey() + " - " + entry.getValue());
		}
		
// 		Output
		
// 		Narasimha - 3
// 		CV - 4
// 		SV - 2

	}

}
