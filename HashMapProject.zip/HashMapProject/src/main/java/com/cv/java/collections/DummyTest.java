/**
 * 
 */
package com.cv.java.collections;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.cv.java.keys.Dummy;

/**
 * @author Chandra
 *
 */
public class DummyTest {
	static {
		disableWarning();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
// 		Created a empty HashMap with Dummy as a Key and Integer as a value.
		Map<Dummy, Integer> map = new HashMap<>();
// 		Six(6) entries (elements) are adding to HashMap
		map.put(new Dummy("AaAaAaAa"), 1);
		map.put(new Dummy("BBBBBBBB"), 2);
		map.put(new Dummy("AaBBAaBB"), 3);
		map.put(new Dummy("BBAaBBAa"), 4);
		map.put(new Dummy("AaAaBBBB"), 5);
		map.put(new Dummy("BBBBAaAa"), 6);
		try {

			Field tableField2 = map.getClass().getDeclaredField("threshold");
			tableField2.setAccessible(true);
			System.out.println("Threshold of the map after adding 6 entries : : " + tableField2.get(map));
// 			Threshold of the map after adding 6 entries : : 12

			Field tableField = map.getClass().getDeclaredField("table");
			tableField.setAccessible(true);
			System.out.println(
					"Capacity of the map after adding 6 entries : : " + ((Object[]) tableField.get(map)).length);
// 			Capacity of the map after adding 6 entries : : 16

// 			Four(4) more entries (elements) are adding to HashMap

			map.put(new Dummy("AaAaAaBB"), 7);
			map.put(new Dummy("BBBBBBAa"), 8);
			map.put(new Dummy("AaBBAaAa"), 9);
			map.put(new Dummy("BBAaBBBB"), 10);
			
			System.out.println("Getting Map ::");
			
			System.out.println("Value for the key - AaBBAaAa :: " + map.get(new Dummy("AaBBAaAa")));

// 			Four(4) more entries (elements) are adding to HashMap
			map.put(new Dummy("AaAaBBAa"), 11);
			map.put(new Dummy("BBBBAaBB"), 12);
			
			System.out.println("Added 12 entires to the HashMap...");
			
			map.put(new Dummy("BBAaAaBB"), 13);
			map.put(new Dummy("AaBBBBAa"), 14);
			
			System.out.println("Added 14 entires to the HashMap...");

			System.out.println("Size of the map is after adding 14 entries : : " + map.size());
// 			Size of the map is after adding 14 entries : : 13

			System.out.println("Threshold of the map  after adding 14 entries : : " + tableField2.get(map));
// 			Threshold of the map  after adding 14 entries : : 24

			System.out.println(
					"Capacity of the map  after adding 14 entries : : " + ((Object[]) tableField.get(map)).length);
// 			Capacity of the map  after adding 14 entries : : 32

// 			Two(2) more entries (elements) are adding to HashMap
			map.put(new Dummy("AaAaBBBB"), 15);
			map.put(new Dummy("ABC"), 16);
			
			System.out.println("Getting Map ::");
			
			System.out.println("Value for the key - AaBBBBAa :: " + map.get(new Dummy("AaBBBBAa")));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void disableWarning() {
		System.err.close();
		System.setErr(System.out);
	}

}
//      Output		

// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		Threshold of the map after adding 6 entries : : 12
// 		Capacity of the map after adding 6 entries : : 16
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		Value for the key - AaBBAaAa :: 9
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)

// 		Size of the map is after adding 14 entries : : 14
// 		Threshold of the map after adding 14 entries : : 48
// 		Capacity of the map after adding 13 entries : : 64
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : hashCode - 64609
// 		In - com.cv.java.keys.Dummy : : hashCode - -540425953
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : compareTo(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		In - com.cv.java.keys.Dummy : : equals(-)
// 		Value for the key - AaBBBBAa :: 14
