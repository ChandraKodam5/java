/**
 * 
 */
package com.cv.java.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cv.java.keys.Address;
import com.cv.java.keys.Employee;

/**
 * @author Chandra
 *
 */
public class CustomKeyAsAddressAndValueAsEmployeeInHashMap {
	/**
	 * @param args
	 */
	public static void main(String[] args) {

// 		Using a custom object (Address) as a Key to HashMap
// 		Overridden equals(Object), hashcode and compareTo(Object) methods in Address class
// 		It is mandatory to override equals(Object), hashCode and compareTo(Object) methods,
// 		when we are using a custom class as a KEY to HashMap or Hashtable
		Address address1 = new Address("Hy", "In");
		Address address2 = new Address("LA", "US");
		Address address3 = new Address("LDN", "UK");
		Address address4 = new Address("Hy", "In");

//		Using a custom object (Employee) as a VALUE to HashMap
// 		Overridden equals(Object), hashcode and compareTo(Object) methods in Employee class
// 		It is NOT mandatory to override equals(Object), hashCode and compareTo(Object) methods,
// 		when we are using a custom class as a VALUE to HashMap, HashSet or Hashtable
		Employee employee1 = new Employee(101, "CV", 4000.00);
		Employee employee2 = new Employee(102, "SV", 5000.00);
		Employee employee3 = new Employee(103, "Narasimha", 5500.00);
		Employee employee4 = new Employee(101, "Chandra", 5000.00);
		
//		Created a empty HashMap with Address as a Key and Employee as a value.
		Map<Address, Employee> addresses = new HashMap<>();

// 		address4 should replace the address1 because both keys(contents) are equal.
// 		And, 101, CV, 4000.00 value should replace with 101, Chandra, 5000.00 value
		addresses.put(address1, employee1);
		addresses.put(address2, employee2);
		addresses.put(address3, employee3);
		addresses.put(address4, employee4);
		System.out.println();
		int i = 0;
		for (Entry<Address, Employee> entry : addresses.entrySet()) {
			System.out.println("Key : : " + ++i);
			System.out.println(entry.getKey());
			System.out.println("Value : : " + i);
			System.out.println(entry.getValue());
			System.out.println();
		}

// 		Output
		/**
		 * Only Address class hashCode and equals methods are executed. 
		 * Means, Key class related ( hashCode and equals ) methods are executed.
		 * And, Value class related methods are NOT executed.
		 */		
// 		In - com.cv.java.keys.Address : : hashCode - 76277
// 		In - com.cv.java.keys.Address : : hashCode - 78730
// 		In - com.cv.java.keys.Address : : hashCode - 2335553
// 		In - com.cv.java.keys.Address : : hashCode - 89110
// 		In - com.cv.java.keys.Address : : equals(-)

// 		Key : : 1
// 		Address [city=LDN, country=UK]
// 		Value : : 1
// 		Employee [id=103, name=Narasimha, salary=5500.0]

// 		Key : : 2
// 		Address [city=Hy, country=In]
// 		Value : : 2
// 		Employee [id=101, name=Chandra, salary=5000.0]

// 		Key : : 3
// 		Address [city=LA, country=US]
// 		Value : : 3
// 		Employee [id=102, name=SV, salary=5000.0]

	}

}
