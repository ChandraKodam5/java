package com.cv.java.object;

import java.io.Serializable;

/**
 * @author Chandra
 * 
 */

// Created a Employee class which implements Cloneable & Serializable interfaces
// Overridden clone() method
// Provided default values for name="CV" and id=101 fields
public class Employee implements Cloneable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name = "CV";
	private int id = 101;

	public Employee() {

	}

	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();

	}
}