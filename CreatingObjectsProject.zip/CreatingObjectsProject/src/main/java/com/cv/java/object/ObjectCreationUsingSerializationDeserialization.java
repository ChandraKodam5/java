/**
 * 
 */
package com.cv.java.object;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Chandra
 *
 */

//Created a ObjectCreationUsingSerializationDeserialization class to explain the object creation
// by using Serialization & Deserialization concept
// In case, we want to apply Serialization & Deserialization concept on any class then that class
// should implement Serializable interface
public class ObjectCreationUsingSerializationDeserialization {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			Employee employee = new Employee();
			String fileName = "inputFile.ser";
			serialize(fileName, employee);
			deSerialize(fileName);
		} catch (Exception e) {
			System.err.println("Exception is caught" + e.getStackTrace());
		}

	}

	// Created a method to Serialize the Employee object and storing into a file
	private static void serialize(final String fileName, final Employee employee) {
		try {
			FileOutputStream file = new FileOutputStream(fileName); // Saving of object in the file
			ObjectOutputStream out = new ObjectOutputStream(file);
			out.writeObject(employee); // serialize object
			out.close(); // closes the ObjectOutputStream
			file.close(); // closes the file
			System.out.println("Object serialized :: " + employee);
		} catch (IOException e) {
			System.err.println("IOException is caught" + e.getStackTrace());
		}
	}

	// Created a method to deSerialize the file
	private static void deSerialize(final String fileName) {
		Employee employee;
		try {
			// Reading an object from a file
			FileInputStream file = new FileInputStream(fileName);
			ObjectInputStream is = new ObjectInputStream(file);
			employee = (Employee) is.readObject(); // deserialize object
			is.close(); // closes the ObjectInputStream
			file.close(); // closes the file
			System.out.println("Object deserialized :: ");
			System.out.println("Name = " + employee.getName());
			System.out.println("id = " + employee.getId());
		} catch (IOException e) {
			System.err.println("IOException is caught" + e.getStackTrace());
		} catch (ClassNotFoundException e) {
			System.err.println("ClassNotFoundException is caught" + e.getStackTrace());
		}
	}

}
