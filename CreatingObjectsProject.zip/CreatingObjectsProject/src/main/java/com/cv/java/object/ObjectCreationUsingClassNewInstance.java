/**
 * 
 */
package com.cv.java.object;

/**
 * @author Chandra
 *
 */
// Created a ObjectCreationUsingClassNewInstance class to explain the object creation by using
// Class class newInstance() method
public class ObjectCreationUsingClassNewInstance {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			// Creating an Employee object using Class class newInstance method
			Employee employee = Employee.class.newInstance();
			System.out.println(employee);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
