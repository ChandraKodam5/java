/**
 * 
 */
package com.cv.java.object;

/**
 * @author Chandra
 *
 */
// Created a ObjectCreationUsingNewOperator class to explain the object creation
// by using new operator
// This is the very common method to create the object in Java
public class ObjectCreationUsingNewOperator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Creating an Employee object by using new operator
		Employee employee = new Employee();
		System.out.println(employee);

	}

}
