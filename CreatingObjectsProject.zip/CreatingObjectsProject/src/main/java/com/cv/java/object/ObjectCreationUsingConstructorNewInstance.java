/**
 * 
 */
package com.cv.java.object;

import java.lang.reflect.Constructor;

/**
 * @author Chandra
 *
 */
// Created a ObjectCreationUsingConstructorNewInstance class to explain the object creation 
// by using Constructor class newInstance() method
public class ObjectCreationUsingConstructorNewInstance {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			// Getting the Constructor object from a class reference
			Constructor<Employee> object = Employee.class.getConstructor();
			// Creating an Employee object from the Constructor object using newInstance
			Employee employee = object.newInstance();
			System.out.println(employee);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
