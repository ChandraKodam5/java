/**
 * 
 */
package com.cv.java.object;

/**
 * @author Chandra
 *
 */
// Created a ObjectCreationUsingClone class to explain the object creation by using
// Object class clone() method
// In case, we want to apply cloning concept on any class then that class
// should implement Clonable interface
public class ObjectCreationUsingClone {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creating an Employee object by using new operator
		Employee employee = new Employee();
		try {
			// Creating an Employee object by using clone method
			Employee employee2 = (Employee) employee.clone();
			System.out.println(employee2);		
			// Comparing the two employee 
			System.out.println(employee == employee2);
		} catch (CloneNotSupportedException e) {
			System.err.println("Error has occurred while creating the object with clone method");
			e.printStackTrace();
		}

	}

}
