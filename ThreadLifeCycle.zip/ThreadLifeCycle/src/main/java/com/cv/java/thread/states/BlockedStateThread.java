package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a BlockedStateThread class which implements Runnable interface
//Overridden run() method
public class BlockedStateThread implements Runnable {
    @Override
    public void run() {
        commonResource();
    }
    
    public static synchronized void commonResource() {
        while(true) {
            // Infinite loop to mimic heavy processing
            // 't1' won't leave this method
            // when 't2' try to enter this
        }
    }
}