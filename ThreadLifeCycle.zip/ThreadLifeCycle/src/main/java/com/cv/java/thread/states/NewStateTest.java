/**
 * 
 */
package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a NewStateTest class
//Using this class to test the thread new state concept
public class NewStateTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Created Thread1 using NewThread
		Thread t = new Thread(new NewThread());
		System.out.println("State of the thread is :: " + t.getState());

	}

}
