package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a TerminatedStateTest class by implementing Runnable interface
//Using this class to test the thread states
public class TerminatedStateTest implements Runnable {
	public static void main(String[] args) throws InterruptedException {
		//Created Thread1 using TimedWaitingThread
		Thread t1 = new Thread(new TerminatedStateTest());
		//Starting the thread
		t1.start();
		// The following sleep method will give enough time for
		// thread t1 to complete
		Thread.sleep(1000);
		System.out.println("State of the thread is :: "+t1.getState());
	}

	@Override
	public void run() {
		// No processing in this block
	}
}