package com.cv.java.thread;
/**
 * @author Chandra
 *
 */
//Java program to demonstrate thread states
//Created a FirstThread class which implements Runnable interface
//Overridden run() method
public class FirstThread implements Runnable {

	
	@Override
	public void run() {
		SecondThread secondThread = new SecondThread();
		Thread thread2 = new Thread(secondThread);	
		
		// SecondThread created and is currently in the NEW state.
		System.out.println("State of thread2 after creating it - " + thread2.getState());
		thread2.start();

		// SecondThread moved to Runnable state
		System.out.println("State of thread2 after calling .start() method on it - " + thread2.getState());

		// moving SecondThread to timed waiting state
		try {
			// moving SecondThread to timed waiting state
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("State of thread2 after calling .sleep() method on it - " + thread2.getState());

		try {
			// waiting for SecondThread to die
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("State of thread2 when it has finished it's execution - " + thread2.getState());

	}
}
