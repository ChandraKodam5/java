package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a NewThread class which implements Runnable interface
//Overridden run() method
public class NewThread implements Runnable {
	public void run() {
		System.out.println();
	}

}