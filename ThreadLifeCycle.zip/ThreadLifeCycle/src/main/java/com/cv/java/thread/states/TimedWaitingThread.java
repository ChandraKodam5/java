package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a TimedWaitingThread class which implements Runnable interface
//Overridden run() method
public class TimedWaitingThread implements Runnable {
	@Override
	public void run() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			System.err.println("Thread interrupted" + e.getMessage());
		}
	}
}