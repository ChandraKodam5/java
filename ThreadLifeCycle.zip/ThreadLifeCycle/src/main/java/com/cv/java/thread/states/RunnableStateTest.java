/**
 * 
 */
package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */

//Created a ScheduledThreadPoolExecutorTest2 class
//Using this class to test the thread scheduler concept
public class RunnableStateTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Created Thread using NewThread
		Thread t1 = new Thread(new NewThread());
		// Starting thread1
		t1.start();
		System.out.println("State of the thread is :: " + t1.getState());
	}

}
