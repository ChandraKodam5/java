package com.cv.java.thread.states;
/**
 * @author Chandra
 *
 */
//Created a SecondWaitingThread class which implements Runnable interface
//Overridden run() method
public class SecondWaitingThread implements Runnable {
   
    public void run() {
    	//Created Thread2 using FirstWaitingThread
        Thread t2 = new Thread(new FirstWaitingThread());
        //Starting the thread
        t2.start();

        try {
            t2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Thread interrupted :: "+ e.getMessage());
        }
    }
}

