package com.cv.java.thread.schedular;

import java.util.Date;

/**
 * @author Chandra
 *
 */
//Created a FirstThread class which implements Runnable interface
//Overridden run() method
public class FirstThread implements Runnable {
	
	private String name;

	public FirstThread(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@Override
	public void run() {
		try {
			System.out.println("Doing a task during : " + name + " - Time - " + new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}