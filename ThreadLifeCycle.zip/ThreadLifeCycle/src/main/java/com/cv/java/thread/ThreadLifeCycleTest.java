package com.cv.java.thread;

/**
 * @author Chandra
 *
 */

//Created a ThreadLifeCycleTest class
//Using this class to test the threads concept & its life cycle.
public class ThreadLifeCycleTest {

	public static Thread thread;
	public static FirstThread obj;

	public static void main(String[] args) {
		obj = new FirstThread();
		thread = new Thread(obj);
		
		// FirstThread created and is currently in the NEW state.
		System.out.println("State of thread1 after creating it - " + thread.getState());
		thread.start();

		// FirstThread moved to Runnable state
		System.out.println("State of thread1 after calling .start() method on it - " + thread.getState());
	}

	

}