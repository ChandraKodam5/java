package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a BlockedStateTest class
//Using this class to test the thread blocked state concept
public class BlockedStateTest {
	
	public static void main(String[] args) throws InterruptedException {
		//Created Thread1 & Thread2 using BlockedStateThread
		Thread t1 = new Thread(new BlockedStateThread());
		Thread t2 = new Thread(new BlockedStateThread());
		//Starting Thread1 & Thread2
		t1.start();
		t2.start();

		Thread.sleep(1000);

		System.out.println("State of the thread is :: " + t2.getState());
		System.exit(0);
	}
}
