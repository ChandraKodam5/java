package com.cv.java.thread.schedular;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
/**
 * @author Chandra
 *
 */
//Created a ScheduledThreadPoolExecutorTest class
//Using this class to test the thread scheduler concept
public class ScheduledThreadPoolExecutorTest {
	
	public static void main(String[] args) {
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);
		FirstThread task1 = new FirstThread("Demo FirstThread 1");
		FirstThread task2 = new FirstThread("Demo FirstThread 2");

		System.out.println("The time is : " + new Date());

		executor.schedule(task1, 5, TimeUnit.SECONDS);
		executor.schedule(task2, 10, TimeUnit.SECONDS);

		executor.shutdown();
	}
}
