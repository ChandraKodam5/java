package com.cv.java.thread.states;
/**
 * @author Chandra
 *
 */
//Created a TimedWaitingStateTest class
//Using this class to test the thread state
public class TimedWaitingStateTest {
	public static void main(String[] args) throws InterruptedException {
		//Created Thread1 using TimedWaitingThread
		Thread t1 = new Thread(new TimedWaitingThread());
		//Starting the thread
		t1.start();

		// The following sleep will give enough time for ThreadScheduler
		// to start processing of thread t1
		Thread.sleep(1000);
		System.out.println("State of the thread is :: " + t1.getState());
	}
}

