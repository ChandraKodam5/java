package com.cv.java.thread.states;
/**
 * @author Chandra
 *
 */

//Created a WaitingStateTest class
//Using this class to test the thread states
public class WaitingStateTest {
	private static Thread t1;
	
	public static Thread getT1() {
		return t1;
	}

	public static void setT1(Thread t1) {
		WaitingStateTest.t1 = t1;
	}

	public static void main(String[] args) {
		//Created Thread1 using SecondWaitingThread
		t1 = new Thread(new SecondWaitingThread());
		//Starting the thread
		t1.start();
	}

}
