package com.cv.java.thread.schedular;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * @author Chandra
 *
 */
//Created a ScheduledThreadPoolExecutorTest2 class
//Using this class to test the thread scheduler concept
public class ScheduledThreadPoolExecutorTest2 {
	public static void main(String[] args) {
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
		FirstThread task1 = new FirstThread("Demo FirstThread 1");

		System.out.println("The time is : " + new Date());

		ScheduledFuture<?> result = executor.scheduleAtFixedRate(task1, 2, 5, TimeUnit.SECONDS);

		try {
			TimeUnit.MILLISECONDS.sleep(20000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		executor.shutdown();
	}
}
