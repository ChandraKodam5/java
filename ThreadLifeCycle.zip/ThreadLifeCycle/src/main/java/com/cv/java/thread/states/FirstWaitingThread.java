package com.cv.java.thread.states;

/**
 * @author Chandra
 *
 */
//Created a FirstWaitingThread class which implements Runnable interface
//Overridden run() method
public class FirstWaitingThread implements Runnable {
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			System.err.println("Thread interrupted :: " + e.getMessage());
		}

		System.out.println("State of the thread is :: " + WaitingStateTest.getT1().getState());
	}

}