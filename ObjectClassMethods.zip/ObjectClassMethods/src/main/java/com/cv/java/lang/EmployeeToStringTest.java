/**
 * 
 */
package com.cv.java.lang;

/**
 * @author Chandra
 *
 */

// Created a EmployeeToStringTest class for testing the toString() method
public class EmployeeToStringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creating an Employee object by using new operator
		Employee employee1 = new Employee("CV", 201);
		// Printing the employee object
		System.out.println(employee1);
		// Printing the employee object by calling toString() method
		System.out.println(employee1.toString());
		
	}

}
