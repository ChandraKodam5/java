/**
 * 
 */
package com.cv.java.lang;
/**
 * @author Chandra
 * 
 */
//Created a FinalizeExample class for testing the finalize() method
public class FinalizeExample {

	
	protected void finalize() throws Throwable {
		try {
			System.out.println("Inside FinalizeExample's finalize()");
		} catch (Throwable e) {

			throw e;
		} finally {
			System.out.println("Calling finalize method of the Object class");
			// Calling finalize() of Object class
			// finalize() method has deprecated in Java 9
			super.finalize();
		}
	}

	// Driver code
	public static void main(String[] args) throws Throwable {

		// Creating FinalizeExample's object
		FinalizeExample obj = new FinalizeExample();

		// Calling finalize of FinalizeExample
		obj.finalize();
	}
}