package com.cv.java.lang;

/**
 * @author Chandra
 * 
 */
// Created a GetClassTest class for testing the getClass() method
public class GetClassTest {
	public static void main(String[] args) {
		Object obj = new String("CV");
		Class c1 = obj.getClass();
		System.out.println("Class of object is : : " + c1.getName());
		
		
		Object obj2 = new RuntimeException();		
		Class c2 = obj2.getClass();
		System.out.println("Class of object is : : " + c2.getName());
				
	}
}