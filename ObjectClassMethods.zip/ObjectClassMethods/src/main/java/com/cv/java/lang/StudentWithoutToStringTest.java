/**
 * 
 */
package com.cv.java.lang;

/**
 * @author Chandra
 *
 */
// Created a StudentWithoutToStringTest class for testing the toString() method
public class StudentWithoutToStringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creating a Student object by using new operator
		Student student1 = new Student("CV", 101);
		// Printing the student object
		System.out.println(student1);
		// Printing the student object by calling toString() method 
		// But, Student class does not override toString() method
		System.out.println(student1.toString());
	}

}
