/**
 * 
 */
package com.cv.java.lang;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Chandra
 *
 */

//Created a ListTostringTest class for testing the toString() method
public class ListTostringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List<String> list = new ArrayList<>();
		list.add("CV");
		list.add("Narasimha");
		//ArrayList has overridden toString() method, due to that, 
		//we are able to see the results properly
		System.out.println(list);
	}

}
