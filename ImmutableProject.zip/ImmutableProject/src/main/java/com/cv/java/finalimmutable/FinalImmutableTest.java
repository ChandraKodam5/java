/**
 * 
 */
package com.cv.java.finalimmutable;

/**
 * @author Chandra
 *
 */
public class FinalImmutableTest {

	private StringBuffer normalField = new StringBuffer("I am Normal Field.");
	private final StringBuffer finalField = new StringBuffer("I am Final Field.");
	private String immutableField = "I am Immutable Field.";
	private final String immutableAndFinalField = "I am Immutable And Final Field.";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FinalImmutableTest fiTest = new FinalImmutableTest();
		fiTest.changeAllFields();
		System.out.println("### --- Output after change! --- ###");
		fiTest.printAllFields();
		fiTest.newAssignmentToAllFields();
		System.out.println("### --- Output after New assignment! --- ###");
		fiTest.printAllFields();

	}

	private void changeAllFields() {
		normalField.append(" I am changed."); // We can change the value
		finalField.append(" I am changed."); // We can still change the value
		immutableField.concat(" I am changed."); // Because of the String immutability
													// the value didn't update to the actual field
		immutableAndFinalField.concat("I am changed.");// Because of the String immutability
														// the value didn't update to the actual field

	}

	private void newAssignmentToAllFields() {
		StringBuffer tempSB = new StringBuffer("I am Normal Field. New assignment possible to Normal field!");
		normalField = tempSB; // Assigning new object is possible

		StringBuffer tempSB2 = new StringBuffer("I am Final Field. New assignment NOT possible to Final field!");
//		finalField = tempSB2; //Assigning new object is NOT possible

		String tempStr = "I am Immutable Field. New assignment possible to immutable field!";
		immutableField = tempStr; // Assigning new object is possible

		String tempStr2 = "I am Immutable And Final Field. New assignment NOT possible to immutable & final field!";

//		immutableAndFinalField = tempStr2; //Assigning new object is NOT possible

	}

	private void printAllFields() {

		System.out.println(normalField);
		System.out.println(finalField);
		System.out.println(immutableField);
		System.out.println(immutableAndFinalField);

	}

}
