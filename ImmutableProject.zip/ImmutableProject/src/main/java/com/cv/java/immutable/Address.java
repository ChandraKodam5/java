package com.cv.java.immutable;

/**
 * @author Chandra
 */

public final class Address {

	private final String city;
	private final String country;

	
	public Address(final String state, final String country) {
		super();
		this.city = state;
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public String getCountry() {
		return country;
	}


	@Override
	public String toString() {
		return "Address [city=" + city + ", country=" + country + "]";
	}

}
