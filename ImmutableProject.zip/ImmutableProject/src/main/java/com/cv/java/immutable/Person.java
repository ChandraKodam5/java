package com.cv.java.immutable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Chandra
 */
// An immutable class named as Person
public final class Person {
	
	private final String name;
	private final int age;
	private final Address address;
	private final List<String> mobileNumbers;
	private final Map<Integer, String> hobbies;
	
	public Person(String name, int age, Address address, List<String> mobileNumbers, Map<Integer, String> hobbies) {
		super();
		this.name = name;
		this.age = age;
		this.address=address;
		
		List<String> tempMobileNumbers = new ArrayList<String>();	
		
		for (String mn : mobileNumbers) {
			tempMobileNumbers.add(mn);
		}
		
		this.mobileNumbers = tempMobileNumbers;

		Map<Integer,  String> tempHobbies = new HashMap<>();
		for (Map.Entry<Integer,  String> entry : hobbies.entrySet()) {
			tempHobbies.put(entry.getKey(), entry.getValue());
		}
		this.hobbies = tempHobbies;		
	}


	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public Address getAddress() {
		return address;
	}

	public List<String> getMobileNumbers() {
		List<String> tempMobileNumbers = new ArrayList<String>();			
		for (String mn : this.mobileNumbers) {
			tempMobileNumbers.add(mn);
		}
		return tempMobileNumbers;
	}	
		
	public Map<Integer, String> getHobbies() {
		Map<Integer, String> tempMap = new HashMap<>();
		for (Map.Entry<Integer, String> entry : this.hobbies.entrySet()) {
			tempMap.put(entry.getKey(),  entry.getValue());
		}
		return tempMap;
	}
		
	
}
