package com.cv.java.immutable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Chandra
 */

// ImmutableTest class

public class ImmutableTest {
	public static void main(String[] args) {
		Map<Integer, String> hobbies = new HashMap<>();
		hobbies.put(1, "Reading");
		hobbies.put(2, "Cooking");
		Address addr = new Address("Hyd", "IN");

		List<String> mobiles = new ArrayList<String>();
		mobiles.add("XXX-XXX-1234");
		mobiles.add("XXX-XXX-9999");

		Person person = new Person("Chandra", 34, addr, mobiles, hobbies);
		System.out.println(person.getName());
		System.out.println(person.getAge());
		System.out.println(person.getHobbies());
		System.out.println(person.getAddress());

		// Uncommenting below line causes error
		// s.age = 102;

		hobbies.put(3, "Swimming");
		//person.getAddress().setCity("Ban");
		mobiles.add("XXX-XXX-1111");
		System.out.println(person.getHobbies()); // Remains unchanged due to deep copy in constructor
//		System.out.println(person.getAddress());
		System.out.println(person.getMobileNumbers());// Remains unchanged due to deep copy in constructor

		person.getHobbies().put(4, "Travelling");
		person.getMobileNumbers().add("XXX-XXX-2222");
		System.out.println(person.getHobbies()); // Remains unchanged due to deep copy in getter
		System.out.println(person.getMobileNumbers());// Remains unchanged due to deep copy in getter
		System.out.println();
	}
}