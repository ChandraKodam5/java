package com.cv.java.wait.notify;

/**
 * @author Chandra
 *
 */
//Created a Data class
//which has send() and receive() methods
public class Data {
	private String packet;

	// true if receiver should wait
	// false if sender should wait
	private boolean transfer = true;

	public synchronized void send(String packet) {
		while (!transfer) {
			try {
				wait();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				System.err.println("Thread interrupted" + e.getMessage());
			}
		}
		transfer = false;

		this.packet = packet;
		notify();
	}

	public synchronized String receive() {
		while (transfer) {
			try {
				wait();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				System.err.println("Thread interrupted" + e.getMessage());
			}
		}
		transfer = true;

		notify();
		return packet;
	}
}