
package com.cv.java.wait.notifyall;

import java.util.Date;

/**
 * @author Chandra
 *
 */
//Created a Waiter class which implements Runnable interface
//Overridden run() method
public class Waiter implements Runnable {

	private Message message;

	public Waiter(Message m) {
		this.message = m;
	}

	@Override
	public void run() {
		String name = Thread.currentThread().getName();
		synchronized (message) {
			try {
				System.out.println(name + " waiting to get notified at time:" + new Date());
				message.wait();
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				System.err.println("Occured Exception :: " + e.getMessage());
			}
			System.out.println(name + " waiter thread got notified at time:" + new Date());
			// process the message now
			System.out.println(name + " Processed: " + message.getMessage());
		}
	}

}