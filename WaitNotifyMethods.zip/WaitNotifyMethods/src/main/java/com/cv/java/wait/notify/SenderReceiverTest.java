/**
 * 
 */
package com.cv.java.wait.notify;

/**
 * @author Chandra
 *
 */
//Created a SenderReceiverTest class
//It is used to test Sender and Receiver Test
//wait() and notify() methods communication test
public class SenderReceiverTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Data data = new Data();
		Thread sender = new Thread(new Sender(data));
		Thread receiver = new Thread(new Receiver(data));

		sender.start();
		receiver.start();
	}

}
