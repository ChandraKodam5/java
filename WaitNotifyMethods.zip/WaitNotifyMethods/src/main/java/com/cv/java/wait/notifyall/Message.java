package com.cv.java.wait.notifyall;

/**
 * @author Chandra
 *
 */
//Created a Message class
public class Message {
	private String message;

	public Message(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
